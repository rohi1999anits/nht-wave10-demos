import React, {useState, useEffect} from 'react'
import axios from 'axios';

export default function Post() {

    const[posts, setPosts] = useState([]);

    useEffect(() => {
     axios.get('https://jsonplaceholder.typicode.com/posts')
     .then(resp => {
         setPosts(resp.data);
     })  
    })

    return (
        <div>
            <table style={{backgroundColor:'cyan'}} >
                {
                    posts.map((post) => 
                    <tr>
                        <td>{post.userId}</td>
                        <td>{post.id}</td>
                        <td>{post.title}</td>
                        <td>{post.body}</td>
                    </tr>
                    )
                }
                
            </table>
        </div>
    )
}
