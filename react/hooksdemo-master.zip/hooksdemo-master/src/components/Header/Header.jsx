import React from 'react'

export default function Header() {
    return (
        <header>
            React SPA for TODO Application
        </header>
    )
}
