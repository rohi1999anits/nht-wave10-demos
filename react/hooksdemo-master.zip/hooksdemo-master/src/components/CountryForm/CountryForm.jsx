import React, {useState} from 'react'

export default function CountryForm() {

    const [countries, setCountries] = useState([
        "India",
        "Russia",
        "Japan"
    ])
    
    return (
        <div>
            <input type="text" id="country" />
            <button onClick={() => {setCountries([...countries, document.getElementById('country').value])}} >
                Add Country</button>
            <hr />
            <br/>
            <h2>Countries List</h2>
            <ul>
                {
                    countries.map(countryName =>
                        <li>{countryName}</li>
                    )
                }
            </ul>
        </div>
    )
}
