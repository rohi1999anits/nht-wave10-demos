import React, { Component } from 'react'

export default class ProductClassComponent extends Component {
    myTitle = 'Class Level Title';
    state = {
        products:[{id:'1', name:'Television', price:'45000'}],
        id:'',
        name:'',
        price:'',
        title:'',
    }
    
    componentDidMount() {
        this.myTitle = 'Process';
        this.setState({title:'Add New Product'});
    }

    getHr() {
        return (<hr />);
    }

    AddHandler(productForm) {
        productForm.preventDefault();
        this.setState({products:[...this.state.products, {id:this.state.id, name:this.state.name, price:this.state.price}]});
    }

    render() {
        return (
            <div>
               <form action="" onSubmit={this.AddHandler.bind(this)}>
                Prouct Id <input type="text" onChange={(e) => {this.setState({id:e.target.value})}}/>
                <br />
                Prouct Name <input type="text"  onChange={(e) => {this.setState({name:e.target.value})}}/>
                <br />
                Prouct Price <input type="text"  onChange={(e) => {this.setState({price:e.target.value})}}/>    
                <br />
                <input type="Submit" value={this.state.title} />
               </form> 
                <div>
                {this.getHr()}
                <table>
                   { this.state.products.map((product) =>
                        <tr>
                            <td>{product.id}</td>
                            <td>{product.name}</td>
                            <td>{product.price}</td>
                        </tr>
                    )}
                </table>
                </div>
            </div>
        )
    }
}