import React, {useState} from 'react'

export default function AddToDo() {

    const [name, setName] = useState('Harish'); // this.state = {name:'Harish'}
    const [action, setAction] = useState('No work');

    const[toDo, setToDo] = useState(
        [{name:'Harish', action:'Monthly Bill Payment'}]
    )

    const addToDoItem = () => {
        setToDo([...toDo, {name:document.getElementById('name').value, action:action}])
    }



    return (
        <div>
            Name - <input type="text" name="" id="name" 
            onChange={(e)=>setName(e.target.value)}/>
            <br/>
            Action - <input type="text" 
            onChange={(e) => setAction(e.target.value)}/>
            <br/>
            <button onClick={addToDoItem}>Add Item</button>
            <br />
            <p>Name - {name}</p>
            <p>Action - {action}</p>
            <table>
               {
                   toDo.map(item =>
                        <tr>
                            <td>{item.name}</td>
                            <td>{item.action}</td>
                        </tr>
                    )
               } 
            </table>
        </div>
    )
}

