const HeaderStyle = {
    'background-color':'cyan', 'width':'100vv', 'height':'13vh'
}
const FooterStyle = {
    'background-color':'lightgreen', 'width':'100vv', 'height':'13vh'
}
const Header = (props) => {
    return(
        <header style={HeaderStyle}> 
            {props.title}
        </header>
    );
}

function Footer(props) {
    return (
        <footer style={FooterStyle}>
            {props.company}.
            {props.copyright}</footer>
    );
}

const MainContent = () => {
    return (
        <h3>This is Main Content !!! </h3>
    )
}

ReactDOM.render(
    <section>
        <Header title="My React Application"/>
        <MainContent /> 
        <Footer company="Stackroute, 2021" copyright="All Right Reserved ! "/>
    </section>, 
    document.getElementById('root'));