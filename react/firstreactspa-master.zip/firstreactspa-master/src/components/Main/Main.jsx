import React from 'react';
import ProductList from '../Product/ProductList';
import AddItem from '../AddItem/AddItem';

function clickHandler(data) {
    alert(data.target.value);
}

export default function Main() {

    const okHandler = () => {
        alert('ok button pressed');
    }

    return (
        <main>
            Main Content
            <ProductList />
            <input type="text" onChange={(data) => clickHandler(data)} />
            <button class="btn btn-primary" onClick={okHandler}>Click Me</button>

            <AddItem title="Class Component created by - "/>
        </main>
    )
}
