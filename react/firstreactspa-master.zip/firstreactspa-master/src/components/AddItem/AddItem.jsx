import React, { Component } from 'react'

export default class AddItem extends Component {

    constructor(props) {
        super(props)
        this.state = {
            name: '',
            address: '',
            title:this.props.title
        }
    }
   
    componentDidMount() {
        this.setState({name:'Harish'})
    }

    componentWillUnmount() {
    }

    clickHandler() {
        alert('Button clicked')
    }

    render() {
        return (
            <div>
                Your Name <input type="text" id="empName" name="empName" 
                onChange = {(e) => this.setState({name:e.target.value})} />
                <br/>
                <br/>
                <button onClick={this.clickHandler}>Add Item</button>
                <br />
                
                <p>title from state - {this.state.title} ==> {this.state.name}</p> 
                <p>Title from props - {this.props.title}</p> 
            </div>
        )
    }
}
