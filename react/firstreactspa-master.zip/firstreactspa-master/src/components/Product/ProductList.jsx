import React from 'react';
import Product from './Product'

export default function ProductList() {
    const products = [
        {id:1, name:'Chain'},
        {id:2, name:'Bangle'},
        {id:3, name:'Chain'},
        {id:4, name:'Ring'},
    ];

    return(
        <table className="table table-bordered">
            {
                products.map(item => 
                    <Product id={item.id} name={item.name} />
                )
            }
        </table>
    )
}