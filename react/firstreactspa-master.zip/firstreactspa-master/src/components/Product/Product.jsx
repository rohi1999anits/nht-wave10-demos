// Take Product id and name and show in table row

import React from 'react';

export default function Product(props) {
    return (
            <tr>
                <td>{props.id}</td>
                <td>{props.name}</td>
            </tr>
    )    
} 