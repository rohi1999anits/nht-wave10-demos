import React from 'react';

function Footer() {
    return (
        <footer>Stackroute, 2021.  All Rights Reserved ! </footer>
    );
}

export default Footer;