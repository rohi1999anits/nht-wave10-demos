import React from 'react'

export default function ContactUs() {
    return (
        <div>
            Contact Us Component display here.....
        </div>
    )
}
