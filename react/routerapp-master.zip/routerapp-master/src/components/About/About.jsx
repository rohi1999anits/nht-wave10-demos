import React from 'react'

export default function About() {
    return (
        <div>
            <h2>About Us..........</h2>
        </div>
    )
}
