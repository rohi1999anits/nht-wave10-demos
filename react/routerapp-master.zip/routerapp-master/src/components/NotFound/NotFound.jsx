import React from 'react'

export default function NotFound() {
    return (
        <div>
            404 -- Content Not Found
        </div>
    )
}
