import React from 'react'

export default function Home() {
    return (
        <div class="row">
            <div className="col-md-6 offset-2">
                Some contents from Home Component
            </div>
        </div>
    )
}
