
#RDBMS-> Relational Database Management System
#Relation = Table = Entity <=>(Java) Model class = POJO
#Row = tuples = records
#Columns = Fields = Attributes
#MySQL, Oracle, MSSQLServer, DB2, Sybase, H2

#Language of RDBMS -> Stuctured Query Language
						#1. DDL-> Data Definition Language--> CREATE, ALTER, DROP
						#2. DML-> Data Manipulation Language-->DELETE, INSERT, UPDATE, TRUNCATE
                        #3. DQL -> Data Query Language--> SELECT
                        #4. DCL -> Data Control Language--> GRANT REVOKE

create database IBM10 ; 

use IBM10;   

create table MyStudents 
  (
  stuID int,
  stuName varchar(30),
  stuEmail varchar(50),
  stuScore int,
  stuSubject varchar(20)
  
  );
  
  
  create table MyStudents 
  (
  stuID int  primary key,
  stuName varchar(30) not null,
  stuEmail varchar(50) unique key,
  stuScore int not null,
  stuSubject varchar(20) not null
  
  );
  
  select * from MyStudents;
  
  drop table MyStudents;
  
  delete from MyStudents where stuID = 101;
 
 
 insert into MyStudents values(101,'Peter','peter@gmail.com',80,'Java');
  insert into MyStudents values(102,'Seth','seth@gmail.com',82,'Testing');
  insert into MyStudents values(103,'Penelope','penelope@gmail.com',89,'Python');
  insert into MyStudents values(104,'Richard','richy@gmail.com',72,'Java');
  insert into MyStudents values(105,'Joan','joan@gmail.com',65,'Java');
  
  
  alter table MyStudents Add Primary Key (stuID);
  
  
  delete from MyStudents;# Deleted magic table is created and it is possible to rollback the deleted data
  
  truncate table MyStudents; # turning your table into 0 bytes without creating any magic tables
  
  update MyStudents set stuScore = 72
  where  stuID = 104;
  
  select * from MyStudents;
  
  select stuID, stuName, stuScore, stuSubject
  from MyStudents
  where stuID >101 
  order  by stuScore desc;
  
  select avg(stuScore),stuSubject from MyStudents 
  group by stuSubject
  order by stuSubject desc;
  
  #JOINS-->It is a marriage of two or more tables , based on related columns
  
  use IBM10;
  create table course
  (
  courseID int primary key,
  courseName varchar(30) unique key,
  coursePrice int
    )
  ;
  insert into course values(101,'Java',3000);
  insert into course values(102,'python',4000);
  insert into course values(103,'Testing',5000);
  
  select * from course;
  
  
  select s.stuID, s.stuSubject, s.stuName, c.courseID
  from MyStudents s inner join course c
  on s.stuSubject = c.courseName;
  
  select * from MyStudents;
  
  #Transactions
  
  
  #Triggers--> Triggers are events that are fired on execution of any DDL / DML statement
  
  delimiter //
  CREATE TRIGGER trgDelete
    BEFORE DELETE
    ON course FOR EACH ROW
    begin
   # select * from old
    select * from deleted
Print 'Records  deleted';
    end;
    delimiter ;
    
    delete from course;
    
    
    drop trigger trgDelete;
    
    create trigger ins_ssum before delete
    on course
    for each row
    set @sum=@sum+coursePrice;
    
    drop trigger ins_ssum;
    
  
  SET SQL_SAFE_UPDATES = 0;






               






