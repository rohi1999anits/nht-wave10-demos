import { Inject, Injectable } from '@angular/core';
import { SESSION_STORAGE, LOCAL_STORAGE, localStorageFactory, sessionStorageFactory, StorageService } from 'ngx-webstorage-service';

@Injectable({
  providedIn: 'root'
})
export class WebStorageService {


  STORAGE_KEY ="local_tasklist";
  constructor(@Inject(LOCAL_STORAGE) private storage: StorageService)
   { }

   public storeOnStorageService(taskTitle: string):void
   {
     const currentTaskList = this.storage.get(this.STORAGE_KEY) || [];
     currentTaskList.push({

      title: taskTitle,
     isChecked: true
     });

     this.storage.set(this.STORAGE_KEY, currentTaskList);
     console.log(this.storage.get(this.STORAGE_KEY));
     
   }
}
