import { Component, Input, Output } from '@angular/core';
import { LOCAL_STORAGE, SESSION_STORAGE } from 'ngx-webstorage-service';
import { WebStorageService} from './web-storage.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'LocalSessionStorageApp';


  @Output() public courseName="Angular Development!";

 @Input() public message;

  constructor(private _webstorage: WebStorageService)
  {

  }

  ngOnInit():void{
    const newTask = "New Task"
    this._webstorage.storeOnStorageService(newTask);
  }
}
