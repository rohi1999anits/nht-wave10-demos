import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

 @Input() public parentData;

 @Output() public childEvent = new EventEmitter();

 emitEventChild()
 {
   this.childEvent.emit('This message is going from child component to parent component');
 }
 
}
