import { ErrorHandler, Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError} from 'rxjs/operators';
import { HttpClient, HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import { Employee} from './employee';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http: HttpClient)
   { 

   }

  getEmployees(): Observable<Employee[]>
  {
    return this.http.get<Employee[]>(" http://localhost:3000/employee")
    .pipe(catchError(this.errorHandler));


  }


errorHandler(error: HttpErrorResponse)
{
  return throwError(error.message);
}}