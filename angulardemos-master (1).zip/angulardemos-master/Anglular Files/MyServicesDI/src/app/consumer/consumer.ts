export class Consumer
{
    cid:number;
    cname:string;
    age:number

}