import { Component, OnInit } from '@angular/core';
import { ConsumerService } from './consumer.service';

@Component({
  selector: 'app-consumer',
  templateUrl: './consumer.component.html',
  styleUrls: ['./consumer.component.css']
})
export class ConsumerComponent implements OnInit {

  constructor(private _consumerService: ConsumerService)
   { }

   public cust =[];


  ngOnInit(): void 
  {

    this._consumerService.getConsumer().subscribe(data=> this.cust= data);
    }

}
