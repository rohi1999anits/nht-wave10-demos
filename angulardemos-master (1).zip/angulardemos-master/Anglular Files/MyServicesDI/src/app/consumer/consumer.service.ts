import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Consumer} from './consumer';
import { HttpClient, HttpClientModule, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConsumerService {

  constructor(private http: HttpClient) 
  {

   }

   getConsumer():Observable<Consumer[]>
  {
    return this.http.get<Consumer[]>(" http://localhost:3000/consumer")
    .pipe(catchError(this.errorHandler));
  }

 
  errorHandler(error:HttpErrorResponse)
  {
    return throwError(error.message);
  }
  

}
