import { Component, OnInit } from '@angular/core';
import { Faculty } from './faculty';


@Component({
  selector: 'app-faculty',
  templateUrl: './faculty.component.html',
  styleUrls: ['./faculty.component.css']
})
export class FacultyComponent implements OnInit {



  public facultyName ="Rakesh";

  facObj: Faculty;

  constructor()
   {
     this.facObj = new Faculty('John','john@gmail.com',375473297);
    }

    myTmpVarShow(value)
    {
      console.log(value);
    }
  ngOnInit(): void {
  }

}
