export  class Faculty
{
    facName: string;
    facEmail: string;
    contactNo: number;

    constructor(facName: string,facEmail: string,contactNo: number)
    {
        this.facName = facName;
        this.facEmail = facEmail;
        this.contactNo = contactNo;
    }

}