import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
   title = 'MyApp';
   public btnCsstyle = 'btn btn-danger';
   public companyName ="IBM";

   public age =parseInt(prompt("Enter your age"));
   public IsDisabled;
   constructor()
   {
     if(this.age >18)
     {
       this.IsDisabled = false;

     }
     else
     {
       this.IsDisabled = true;
     }
   }
   
    
   public buttonTxt = "Click Me If you are an Adult!";


   showMsg =($event)=>
   {
     console.log("Click Me Button is clicked!")

     this.buttonTxt = "Generating Log file.......Please Wait!"
     console.log($event);
     setTimeout(()=>
     {
       this.buttonTxt = "Log file created";
     },5000);
   }

   updateCompanyName($event)
   {
     this.companyName = "IBM Global";
     this.companyName = $event.target.value;
     console.log(this.companyName);
   }
}
