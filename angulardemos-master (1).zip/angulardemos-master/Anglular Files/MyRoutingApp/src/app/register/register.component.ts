import { Component, OnInit } from '@angular/core';

import {Route, Router, NavigationExtras, ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private router: Router, private route: ActivatedRoute)
   { }

  public dept =[
    {"id":1},
    {"id":2},
  ];


  goToCat()
  {
                       // register/category
    this.router.navigate([{},'category'],{relativeTo:this.route});
  }

 /* goToDept()
  {
                       // register/category
    this.router.navigate([{},'dept'],{relativeTo:this.route});
  }*/


  ngOnInit(): void {
  }

}
