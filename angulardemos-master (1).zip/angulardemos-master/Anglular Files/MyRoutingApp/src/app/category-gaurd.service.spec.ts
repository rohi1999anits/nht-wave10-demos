import { TestBed } from '@angular/core/testing';

import { CategoryGaurdService } from './category-gaurd.service';

describe('CategoryGaurdService', () => {
  let service: CategoryGaurdService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CategoryGaurdService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
