import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CategoryGaurdService } from './category-gaurd.service';
import { CategoryComponent } from './category/category.component';
import {LoginComponent} from './login/login.component';
import { PipeDemoComponent } from './pipe-demo/pipe-demo.component';
import { RegisterComponent} from './register/register.component';

const routes: Routes = [
  //{path:'',redirectTo:'/login',pathMatch:'full'},
  {path:'login', component:LoginComponent},
  {path:'signup', component:RegisterComponent},
  {path:'signup/category', component: CategoryComponent, canActivate:[CategoryGaurdService]},
  {path:'category', component: CategoryComponent},
 // {path:'pipe', component:PipeDemoComponent},
  {path:'login', component: PipeDemoComponent,
    children:[
      {path:'pipedemo', component: PipeDemoComponent, canActivateChild:[]},
    ]
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
