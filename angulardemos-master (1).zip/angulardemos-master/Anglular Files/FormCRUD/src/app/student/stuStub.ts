import {Student} from './student';

import {Observable}  from 'rxjs';

export class StudentStub
{
    addStudent(stu: Student)
    {
       return new Observable<Student>();
    }
}