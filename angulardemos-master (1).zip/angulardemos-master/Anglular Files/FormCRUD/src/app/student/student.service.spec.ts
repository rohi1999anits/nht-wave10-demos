import { TestBed } from '@angular/core/testing';
import {HttpClient} from '@angular/common/http';

import {HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { StudentService } from './student.service';

fdescribe('StudentService', () => {
  let service: StudentService;

  let httpMock: HttpTestingController;

  let dummyContact={id:1,firstname:"John",email:"john@gmail.com"};
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers:[StudentService],
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(StudentService);
    
    httpMock = TestBed.get(HttpTestingController);
    
   
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch student details from JSON-SERVER',()=>
  {
   
    service.getAllStudents().subscribe(stu=>{
      expect(stu).toEqual([dummyContact]);

    let req = httpMock.expectOne({
      url:'http://localhost:3000/students',
      method: 'GET'
    })

    req.flush([dummyContact]);

   // expect(request.request.body).toEqual(dummyContact);
   console.log(req.request.url);
  // expect(req.request.url.endsWith("/students")).toEqual(true);
  
  })
  });

  it('should add contacts',()=>
  {
    const newContact ={id:1,firstname:"John", email:"John@gmail.com"};

    service.addStudent(newContact).subscribe(stu=>
      {
        expect(stu).toEqual(newContact);
      })
      let req = httpMock.expectOne({
        url:'http://localhost:3000/students',
        method: 'POST'
      })

      req.flush(newContact);
      expect(req.request.body).toEqual(newContact);

     // expect(req.request.url.endsWith("/students")).toEqual(true);
    service.getAllStudents().subscribe(stu=>{
      expect(stu).toEqual([dummyContact, newContact]);
    })

  })
});
