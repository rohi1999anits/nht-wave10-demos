import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentComponent } from './student.component';

import { BrowserModule, By } from '@angular/platform-browser';
import {HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { StudentService } from './student.service';
import { Student } from './student';
import { StudentStub } from './stuStub';



describe('StudentComponent', () => {
  let component: StudentComponent;
  let fixture: ComponentFixture<StudentComponent>;
  let stuService : StudentService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentComponent ],
      imports: [
        BrowserModule,
        HttpClientModule,
        FormsModule
      ],

      providers:[{provide:StudentService, useClass: StudentStub}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentComponent);
    component = fixture.componentInstance;

    stuService = fixture.debugElement.injector.get(StudentService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain blank value input elements',()=>
  {
    let element = fixture.debugElement.query(By.css('input'));

    expect(element).toBeTruthy();
    expect(element.nativeElement.value).toBe('');
  });

  it('should contain button element',()=>
  {
    let element = fixture.debugElement.query(By.css('button'));

    expect(element).toBeTruthy();
    expect(element.nativeElement.value).toBe('submitData');
  });

  it('shouldcall addStudentContact() method',()=>
  {
   spyOn(stuService,'addStudent').and.callThrough();

   let dummyContact = new Student();

   dummyContact.email = 'john@gmail.com';
   dummyContact.firstname =' John';

   component.stu = dummyContact;

   let element = fixture.debugElement.query(By.css('button'));
   element.nativeElement.click();
   fixture.detectChanges();
   expect(stuService.addStudent).toHaveBeenCalledWith(dummyContact);
  })
});
