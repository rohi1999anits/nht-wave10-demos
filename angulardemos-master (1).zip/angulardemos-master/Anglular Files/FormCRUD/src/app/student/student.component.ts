import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { StudentService } from './student.service';
import {HttpClient} from '@angular/common/http';
import { Student } from './student';
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit{

  constructor( private _studentService:StudentService, private http:HttpClient)
   { }

  ngOnInit(): void 
  {
      //this.viewAllStudents();
  }

  /*ngOnChanges(changes: SimpleChanges):void
  {
    this.viewAllStudents();

  }*/

  data: {};

  stu: Student = new Student();
  students:Array<Student>=[];

  addStudentContact()
  {
      
    this._studentService.addStudent(this.stu).subscribe(data=>{
      console.log("Added to JSON DB file",data);
      this.students.push(data);
    },

    error=>
    {
      console.log(error);
    }
    )
    this.stu = new Student();
  }

  viewAllStudents()
  {
    this._studentService.getAllStudents().subscribe(
      data=>
      {
        this.students  = data;
      },
      error=>
      {
        console.log(error);
      }
    )

  }

  deleteStudent(id:number)
  {
    this._studentService.deleteStudent(id).subscribe(
      data=>
      {
        console.log("Record deleted!",data);

        let studentIndex = this.students.findIndex(stu=>stu.id===id);
        console.log(studentIndex);
        //console.log(this.students);
        //this.students.splice(studentIndex,1);
        this.viewAllStudents();
      },
      error=>
      {
        console.log(error);
      }
    )

  }
}
