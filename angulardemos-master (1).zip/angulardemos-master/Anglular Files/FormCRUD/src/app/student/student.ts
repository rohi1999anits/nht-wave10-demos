export class Student{

    id: number;
    firstname: string;
    email:string
}