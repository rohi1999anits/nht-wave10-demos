import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-react-form',
  templateUrl: './react-form.component.html',
  styleUrls: ['./react-form.component.css']
})
export class ReactFormComponent implements OnInit {


  loginForm = new FormGroup(
    {
      firstname: new FormControl('', Validators.required),
      password: new FormControl('', Validators.minLength(4)),
    }
  );

   display:any = null;
  getData()
{
  this.display = JSON.stringify(this.loginForm.value);
  
  console.log(this.loginForm.value);
}
  constructor() { }

  ngOnInit(): void {
  }

  
  get diagnostic()
  {

    return this.loginForm.get('firstname');
  }
}
