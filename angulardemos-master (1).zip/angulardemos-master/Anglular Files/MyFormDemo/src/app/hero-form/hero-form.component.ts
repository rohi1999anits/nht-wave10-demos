import { Component, OnInit } from '@angular/core';
import { Hero } from './hero';


@Component({
  selector: 'app-hero-form',
  templateUrl: './hero-form.component.html',
  styleUrls: ['./hero-form.component.css']
})
export class HeroFormComponent implements OnInit {

  constructor() { }

  //powers: any[] =[{}];

  powers = ['Really Smart','Super Flexible','Super Hot','Weather Changer'];

  model = new Hero(18, 'Superman',this.powers[0],'NY');

  get diagnostic()
  {
    return JSON.stringify(this.model);
  }

  ngOnInit(): void {
  }

}
