package com.app.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.data.jpa.repository.config.EnableMongoRepositories;

import com.app.filter.JWTFilter;


@ComponentScan("com.app.*")
@EnableJpaRepositories(basePackages="com.app.*")
//@EnableMongoRepositories(basePackages="com.app.*")
@EntityScan(basePackages="com.app.*")
@SpringBootApplication
public class SpringBootJpaCrudApplication {

	@Bean
	public FilterRegistrationBean jwtFilter() 
	{
		FilterRegistrationBean fb = new FilterRegistrationBean();
		fb.setFilter(new JWTFilter());
		fb.addUrlPatterns("/api/v1/*");
		return fb;
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaCrudApplication.class, args);
	}

	
}
