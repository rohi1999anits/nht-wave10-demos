package com.app.Repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
//import org.springframework.data.mongo.repository.Query;

import com.app.Model.Employee;

@Repository
@Transactional
public interface EmployeeRepository extends JpaRepository<Employee, Integer>
{

	
	// Do not have to write any CRUD methods like save()/createQuery()/insert()...
	//@Query("{'username':{$in : [?0], 'password':{$in:[?1]}}") //mongoDB
	//@Query("select NEW com.mypackage.CustomerAmountResult(o.customer.surname, sum(o.amount)) 
	//from Order as o
	//group by o.customer.surname")
	//@Query("select NEW com.app.Model.LoginEmployee(e.username, e.password) from Employee e  where  e.username = :username and e.password = :password")
	@Query(value="select e from Employee e where e.username= :username and e.password= :password")
	public Employee validateUser(String username, String password);
}
