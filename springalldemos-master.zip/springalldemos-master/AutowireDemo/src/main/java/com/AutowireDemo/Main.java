package com.AutowireDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) 
	{
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		
		Employee emp = ctx.getBean(Employee.class);
		emp.setId(101);
		emp.setName("John");
		emp.display();
		
		//Employee emp1 = ctx.getBean(Employee.class);
		//emp1.show();
		
		

	}

}
