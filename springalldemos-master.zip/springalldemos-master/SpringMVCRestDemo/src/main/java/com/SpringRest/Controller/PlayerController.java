package com.SpringRest.Controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpringRest.Model.Player;

@RestController
public class PlayerController
{
	
	@RequestMapping("/")
	public String index() {
		return "Welcome to REST API!";
	}
	
	
	
  @RequestMapping("/hello/{msg}")
  public Player index(@PathVariable String msg)
  {
	  Player p = new Player(msg,"Hello "+ msg);
	  return p;
  }
  
  @RequestMapping("/api/v2")
  public String indexNew()
  {
	 return "This is the last endpoint";
  }
	
}
