package com.ResourceBundleDemo;

import java.util.Locale;
import java.util.ResourceBundle;

public class i18nDemo {

	public static void main(String[] args) 
	{
		//ResourceBundle Default = ResourceBundle.getBundle("LangBundle");
		
		//displayLanguageLocale(Default);
		

		Locale french = new Locale("fr","FR");
		ResourceBundle obj2 = ResourceBundle.getBundle("LangBundle",french);
		
		displayLanguageLocale(obj2);
		
		Locale english = new Locale("en");
		ResourceBundle obj1 = ResourceBundle.getBundle("LangBundle",english);
		
		displayLanguageLocale(obj1);
		
		
		
		
		Locale chinese = new Locale("zh","CN");
		ResourceBundle obj3 = ResourceBundle.getBundle("LangBundle",chinese);
		
		displayLanguageLocale(obj3);
		

	}
	
	public static void displayLanguageLocale(ResourceBundle bundle)
	{
		System.out.println(bundle.getString("my.hello"));
		System.out.println(bundle.getString("my.goodbye"));
		System.out.println(bundle.getString("my.question"));
		System.out.println("-------------------------------------------------");
		
	}

}
