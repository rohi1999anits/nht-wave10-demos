package com.SpringContextDemo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Main {

	public static void main(String[] args) 
	{
		User obj ;// creating of reference with null
		obj = new User();// new object created in the memory
		//Initialization => when they are called/ loaded/ invoked
		
		BeanFactory bf;
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		
		Address add1 = ctx.getBean("add1", Address.class);
		Address add2 = ctx.getBean("add2", Address.class);
		
		System.out.println(add1);
		System.out.println(add2);
		
		List<Address> addr = new ArrayList<Address>();
		addr.add(add1);
		addr.add(add2);
		
		
		User user1 = ctx.getBean("user1", User.class);
		user1.setId(201);;
		user1.setName("Keith");
		user1.setEmail("k@gmail.com");
		user1.setPhn("34787324984");
		user1.setAddress(addr);
		
		
		
		UserDO userDO1 = ctx.getBean("userDO1", UserDO.class);
		System.out.println(userDO1);
		
		
		

	}

}
