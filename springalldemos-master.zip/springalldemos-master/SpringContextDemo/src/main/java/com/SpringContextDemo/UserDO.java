package com.SpringContextDemo;

import java.util.List;
import java.util.Map;

public class UserDO 
{
	private Map<User, List<Address>> userAddress; 
	
	
	public Map<User, List<Address>> getUserAddress()
	{
		return userAddress;
	}
	
	public void setUserAddress(Map<User, List<Address>> userAddress)
	{
		this.userAddress = userAddress;
		
		
	}

	public UserDO(Map<User, List<Address>> userAddress) {
		super();
		this.userAddress = userAddress;
	}

	@Override
	public String toString() {
		return "UserDO [userAddress=" + userAddress + "]";
	}
	
	

}
