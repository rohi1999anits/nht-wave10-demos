package com.SpringContextAnnotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.SpringContextAnnotation.Config.AppConfig;
import com.SpringContextAnnotation.Model.User;

public class Main 
{
	//singleton design pattern// single instance of the bean through out the application context
	@Autowired
	private static User usr1;
	
	
	
	public static void main(String [] args)
	{
		 AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		 
		 User usr1 = ctx.getBean(User.class);
		 System.out.println(usr1);
	}

}
