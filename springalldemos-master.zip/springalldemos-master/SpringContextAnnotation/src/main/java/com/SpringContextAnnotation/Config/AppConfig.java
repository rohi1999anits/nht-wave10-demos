package com.SpringContextAnnotation.Config;

import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.SpringContextAnnotation.Model.Address;
import com.SpringContextAnnotation.Model.User;

@Configuration
@ComponentScan("com.SpringContextAnnotation.Model")
public class AppConfig
{

	@Bean("add1")
	//@Qualifier("MyList")
	public Address getAddress1()
	{
		System.out.println("Inside the factory method of Address Bean");
		return new Address(1,"Chicago","USA");
	}
	
	@Bean("add2")
	public Address getAddress2()
	{
		System.out.println("Inside the factory method of Address Bean....");
		return new Address(2,"Delhi","India");
	}
	
	@Bean("user1")
	public User getUser1()
	{
		System.out.println("Inside the factory method of User Bean....");
		return new User (101,"John","john@gmail.com","4354378",new ArrayList(Arrays.asList(getAddress1(), getAddress2())));
		
	}
	
	
}










