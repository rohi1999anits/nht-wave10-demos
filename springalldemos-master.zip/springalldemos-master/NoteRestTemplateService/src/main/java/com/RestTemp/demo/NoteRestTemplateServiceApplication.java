package com.RestTemp.demo;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestClientException;

import com.RestTemp.Controller.ConsumerController;

@ComponentScan(basePackages="com.RestTemp.*")
@SpringBootApplication
public class NoteRestTemplateServiceApplication {

	

	public static void main(String[] args) throws RestClientException, IOException {
		ApplicationContext ctx=SpringApplication.run(NoteRestTemplateServiceApplication.class, args);
		
		ConsumerController cobj = ctx.getBean(ConsumerController.class);
		
		cobj.getJpaService();
		//cobj.getMongoService();
		
		
	}

	
	
}
