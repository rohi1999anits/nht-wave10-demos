package com.RestTemp.Controller;

import java.io.IOException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("api/v1/consumer")
public class ConsumerController 
{
	
	@GetMapping("/getAll")
	public void getJpaService() throws IOException, RestClientException
	{
		System.out.println("Inside JPA service calling!");
		
		String url ="http://localhost:8083/api/v1/getAll";
		
		RestTemplate restTemp = new RestTemplate();
		
		ResponseEntity<String> res = null;
		
		//HttpHeaders httpHeaders = new HttpHeaders();
		
		try
		{
			System.out.println("Inside try block...");
			res = restTemp.exchange(url, HttpMethod.GET,getHeaders(),String.class);
		}
		catch(Exception e)
		{
			
		}
		System.out.println(res.getBody());
	}
	
	private static HttpEntity<?> getHeaders() throws IOException
	{
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
		
	}
	
	
	/*
	 * public void getMongoService() {
	 * 
	 * }
	 */	

}
