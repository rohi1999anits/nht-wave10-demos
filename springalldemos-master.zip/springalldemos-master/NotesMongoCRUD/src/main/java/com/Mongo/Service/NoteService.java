package com.Mongo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Mongo.Model.Note;
import com.Mongo.Repository.NoteRepository;
import com.Mongo.exception.NoteAlreadyExistsException;

@Service
public class NoteService implements INoteDao
{

	@Autowired
	private NoteRepository noteRepo;

	@Override
	public List<Note> getAllNotes() {
		
		List allNotes = this.noteRepo.findAll();
		return allNotes;
	}

	@Override
	public Note saveNote(Note note) throws NoteAlreadyExistsException 
	{
		Optional<Note> optional = this.noteRepo.findById(note.getId());
		if(optional.isPresent())
		{
			throw new NoteAlreadyExistsException();
		}
		Note addNote = this.noteRepo.save(note);
		
		return addNote;
	}
	

}

















