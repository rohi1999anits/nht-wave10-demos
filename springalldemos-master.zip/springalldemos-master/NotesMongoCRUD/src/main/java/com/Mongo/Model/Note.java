package com.Mongo.Model;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="notedb")
public class Note 
{
	@Id
	private String id;
	private String noteTitle;
	private String noteText;
	private String noteCategory;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNoteTitle() {
		return noteTitle;
	}
	public void setNoteTitle(String noteTitle) {
		this.noteTitle = noteTitle;
	}
	public String getNoteText() {
		return noteText;
	}
	public void setNoteText(String noteText) {
		this.noteText = noteText;
	}
	public String getNoteCategory() {
		return noteCategory;
	}
	public void setNoteCategory(String noteCategory) {
		this.noteCategory = noteCategory;
	}
	public Note(String id, String noteTitle, String noteText, String noteCategory) {
		super();
		this.id = id;
		this.noteTitle = noteTitle;
		this.noteText = noteText;
		this.noteCategory = noteCategory;
	}
	public Note() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
