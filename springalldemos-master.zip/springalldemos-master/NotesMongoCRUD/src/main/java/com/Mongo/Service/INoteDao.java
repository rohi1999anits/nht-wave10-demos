package com.Mongo.Service;

import java.util.List;

import com.Mongo.Model.Note;
import com.Mongo.exception.NoteAlreadyExistsException;

public interface INoteDao 
{
	public Note saveNote(Note note) throws NoteAlreadyExistsException;
	
	public List<Note> getAllNotes();
	
	

}
