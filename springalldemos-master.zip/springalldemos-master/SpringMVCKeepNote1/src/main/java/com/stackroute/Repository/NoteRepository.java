package com.stackroute.Repository;

import java.util.ArrayList;
import java.util.List;

import com.stackroute.Model.Note;

public class NoteRepository 
{
	public List<Note> noteData;

	public List<Note> getNoteData() {
		return noteData;
	}

	public void setNoteData(List<Note> noteData) {
		this.noteData = noteData;
	}

	public NoteRepository() {
		
		this.noteData = new ArrayList<Note>();
	}
	
	
	public List<Note> getallNotes()
	{
		return noteData;
	}

	public void addNote(Note note)
	{
		this.noteData.add(note);
	}
	
	public void setList(List<Note> list)
	{
		noteData = list;
	}
	
	public List<Note> getList()
	{
		return noteData;
	}
	
	public void deleteNote(int noteId)
	{
		noteId = noteId-1;
		this.noteData.remove(noteId);
		//System.out.println(noteId);
	}
}
















