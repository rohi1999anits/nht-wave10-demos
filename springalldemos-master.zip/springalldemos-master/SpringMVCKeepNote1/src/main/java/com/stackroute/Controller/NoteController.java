package com.stackroute.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.stackroute.Model.Note;
import com.stackroute.Repository.NoteRepository;


@Controller
public class NoteController
{
	//Downcasting
	ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
	
	Note note = ctx.getBean(Note.class);
	
	
	NoteRepository noteRepository = ctx.getBean("noteRepository",NoteRepository.class);
	
	String id = "101";
	String title = "Meeting at 10am";
	String text = "New Product Lanuch -Sales";
	String cat ="Important";
	
	List<Note> arrayNote = new ArrayList<Note>();
	
	
	public NoteController()
	{
		System.out.println("NoteController triggered...........");
	}

	
	@RequestMapping("/")
	public ModelAndView getIndex()
	{
		System.out.println("Landing Page");
		ModelAndView mv = new ModelAndView();
		mv.addObject("noteList",noteRepository.getallNotes());
		mv.setViewName("index");
		//System.out.println(mv);
		return mv;
		
	}
	
	/*@RequestMapping("/notePage")
	public String getNotePage()
	{
		note.setNoteId(id);
		note.setNoteTitle(title);
		note.setNoteText(text);
		note.setNoteCategory(cat);
		arrayNote.add(note);
		
		
		System.out.println("KeepNote Page");
		noteRepository.setNoteData(arrayNote);
        noteRepository.getNoteData();		
		System.out.println(arrayNote);// console
		
		return "keepnote";
	}*/
	
	@RequestMapping(value="/saveNote", method=RequestMethod.POST)
	public ModelAndView saveNoteFunc(ModelMap modelMap, @RequestParam int noteId, @RequestParam String noteTitle, @RequestParam String noteText, @RequestParam String noteCategory)
	{
		ModelAndView mv = new ModelAndView();
		
		
		Note note1 = (Note) ctx.getBean("note");
		note1.setNoteId(noteId);
		note1.setNoteTitle(noteTitle);
		note1.setNoteText(noteText);
		note1.setNoteCategory(noteCategory);
		noteRepository.addNote(note1);
		System.out.println(noteId);
		modelMap.addAttribute("SavedNotes",noteRepository.getList());
		mv.addObject("noteList",noteRepository.getallNotes());
		mv.setViewName("index");
		//System.out.println(mv);
		return mv;
		
	}
	
	/*@RequestMapping(value="/saveNote", method=RequestMethod.POST)
	public ModelAndView saveNoteFunc(@ModelAttribute("note")Note note, ModelMap modelMap)
	{
		ModelAndView mv = new ModelAndView();
		
		//Note note1 = (Note)ctx.getBean("note");
		this.noteRepository.addNote(note);
		//System.out.println(noteId);
		modelMap.addAttribute("noteList", this.noteRepository.getallNotes());
		mv.addObject(modelMap);
		mv.setViewName("index");
        return mv;		
		
	}*/

	/*@DeleteMapping("/deleteNote/{noteId}")
	public String deleteFunction(@PathVariable("noteId")int noteId)
	{
		//Note note = new Note();
		//ModelAndView mv = new ModelAndView();
		//mv.setViewName("index");
		this.noteRepository.deleteNote(noteId);
		
		//modelMap.addAttribute("noteList",this.noteRepository.getallNotes());
		//mv.addObject(modelMap);
		return "redirect:/";
		
	}*/

	
	@RequestMapping(value="/delete/{noteId}",method=RequestMethod.GET)    
    public String delete(@PathVariable int noteId)
	{
		this.noteRepository.deleteNote(noteId);   
        return "redirect:/";    
    }   
	
	
}

















