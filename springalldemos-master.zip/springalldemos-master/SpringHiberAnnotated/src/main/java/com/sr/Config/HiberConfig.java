package com.sr.Config;

import java.io.IOException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.sr.Model.Note;

@Configuration
@EnableTransactionManagement
public class HiberConfig 
{
	@Bean
	public DataSource GetDataSource()
	{
		BasicDataSource bds = new BasicDataSource();
		bds.setDriverClassName("com.mysql.cj.jdbc.Driver");
		bds.setUrl("jdbc:mysql://localhost:3306/NewDBIBM");
		bds.setUsername("root");
		bds.setPassword("password@123");
		return bds;
	}
	
	@Bean
	public LocalSessionFactoryBean getsessionFac(DataSource ds) throws IOException
	{
		LocalSessionFactoryBean sessionFacBean = new LocalSessionFactoryBean();
		sessionFacBean.setDataSource(ds);
		
		Properties p = new Properties();
		
		p.put("hibernate.show_sql", "true");// hql commands will display in console
		p.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
		p.put("hibernate.hbm2ddl.auto", "update");
		
		sessionFacBean.setHibernateProperties(p);
		sessionFacBean.setAnnotatedClasses(Note.class);
		sessionFacBean.afterPropertiesSet();
		return sessionFacBean;
		
	}
	
	@Bean
	public HibernateTransactionManager getTransactionManager(SessionFactory sessionFac)
	{
		HibernateTransactionManager tm = new HibernateTransactionManager();
		tm.setSessionFactory(sessionFac);
		return tm;
	}

}











