package com.sr.Dao;

import java.util.List;

import com.sr.Model.Note;

public interface INoteDAO 
{

	public boolean saveNote(Note note);// insert operation
	public boolean deleteNote(int noteId);// delete
	
	public List<Note> getAllNotes(Note note);// retrieve
	
	
	
}
