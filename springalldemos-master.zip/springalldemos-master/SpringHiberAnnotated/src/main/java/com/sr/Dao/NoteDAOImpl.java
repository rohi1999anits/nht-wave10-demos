package com.sr.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sr.Model.Note;

@Repository
@Transactional
public class NoteDAOImpl implements INoteDAO
{
	@Autowired
	private SessionFactory sessionFac;// singleton pattern// thru out entire application only 1 instance of sessionFac
	
	
	public boolean saveNote(Note note)
	{try
	{
		this.sessionFac.getCurrentSession().save(note);
		return true;
	}
	catch(Exception e)
	{
		e.printStackTrace();
		return false;
	}
		
	}


	@Override
	public boolean deleteNote(int noteId) 
	
	{
		try
		{
			Note note = this.sessionFac.getCurrentSession().load(Note.class, noteId);
			this.sessionFac.getCurrentSession().delete(note);
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		
	}


	@Override
	public List<Note> getAllNotes(Note note) 
	{
		return this.sessionFac.getCurrentSession().createQuery("from Note").list();
		
	}
	
	
	

}
