package com.sr.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sr.Dao.INoteDAO;
import com.sr.Dao.NoteDAOImpl;
import com.sr.Model.Note;

@Controller
@RequestMapping("/")
public class NoteController 
{
	
	@Autowired
	private INoteDAO noteDao;
	
	@GetMapping("/")
	public ModelAndView getHomePage()
	{
		Note note = new Note();
		ModelAndView mv = new ModelAndView("index");
		
		//mv.setViewName("index");
		mv.addObject("noteList",noteDao.getAllNotes(note));
		return mv;
	}

	@PostMapping("/saveNote")
	public String saveNote(@ModelAttribute("note") Note note, ModelMap modelMap)
	{
		boolean status = noteDao.saveNote(note);
		modelMap.addAttribute("noteList",noteDao.getAllNotes(note));
		return "redirect:/";
	}
	
	@RequestMapping("/deleteNote/{noteId}")
	public String deleteNote(@PathVariable("noteId")int noteId)
	{
		System.out.println(noteId);
		Note note = new Note();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		noteDao.deleteNote(noteId);
		mv.addObject("noteList",noteDao.getAllNotes(note));
		return "redirect:/";
		
	}
}










