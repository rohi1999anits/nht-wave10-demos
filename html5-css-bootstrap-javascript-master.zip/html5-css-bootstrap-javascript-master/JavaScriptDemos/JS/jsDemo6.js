//arrays and loops

var tech = ['Jenkins','Selenium','SpringRest'];

numbersOfStudents =[23,45,67,89];

for(i=0;i<tech.length;i++)
{
    console.log(tech[i]);

}

console.log("Output after using advanced for loop");

for (let value of numbersOfStudents)
{
    console.log(value);
}