//class and objects
var x=23;
let y=20;
class student
{
    
    constructor(name, age)
    {
        this.a=age;
        this.n = name;

    }

    stu()
    {
      var x=8;
      let  y=10;

        console.log("Name of the student "+ this.n);
        console.log("Age of the student "+ this.a);
        console.log(x);
        console.log(y);
    }
}

var stuObj = new student("Penelope", 28);
//console.log(x);


console.log(y);

console.log(x);

stuObj.stu();

console.log(stuObj.x);
console.log(stuObj.y);