let city = new Set(['Chicago','Delhi','Tokyo','London','Sydney','Delhi']);

console.log(city);
console.log(city.size);
//console.log(city.entries);
console.log(city.delete('Delhi'));
console.log(city);
console.log(city.size);
city.add('Chennai');
console.log(city);
console.log(city.size);

for(let item of city)
{
    console.log(item);
}

console.log(item);

for(var items of city)
{
    console.log(items);
}
console.log(items);

