//variable ,var, functions
//JS does not support TYPE.

var person ="Harry";

var x =5.2;

function check()
{
    console.log("Height of "+person+" is: "+x);
}

function display()
{
    age =17;
    console.log("Age of "+person+" is: "+age);
}

check();
display();
