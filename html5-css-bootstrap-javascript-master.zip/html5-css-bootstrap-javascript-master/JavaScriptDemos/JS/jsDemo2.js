//function call by value

var x=10;

function display()
{
    
    const y =2;

    console.log(y);
    console.log(x);
}

function calc(num1, num2)
{
    num3 = num1+num2;

    console.log(num3);
}

display();

calc(3,4);




