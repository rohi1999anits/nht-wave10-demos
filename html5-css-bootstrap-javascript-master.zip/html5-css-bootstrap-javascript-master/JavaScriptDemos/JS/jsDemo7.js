//pre-defined array function


const arrFunc1=()=>
{
    var arr = [77,88,23,33];

    var result = arr.find(x=> x<40);
    console.log(result);
}

arrFunc1();

const arrFunc2=()=>
{
    var arr = [77,88,23,33];

    var result = arr.findIndex(x=> x<40);
    console.log(result);
}

arrFunc2();





