//form validation 

function validatePassword()
{
    var name = document.myPage.name.value;
    var password = document.myPage.password.value;

    if(name===null|| name=="")
    {
        alert("Name cannot be blank!");
        return false
    }

    else if(password.length <8)
    {
        alert("Password length must be >=8");
        return false;
    }
       
    


}