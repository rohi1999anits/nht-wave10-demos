

 x='Hello';
 y ='Stackroute';

 x='Hi';

let y ='IBM';
