//parameterized arrow function

var param =18;
//let abc = 
const ageValidate =(age)=>
{

    if(age<param)
    console.log("Not Adult");
    else
    console.log("Adult");
}

ageValidate(2);
ageValidate(23);