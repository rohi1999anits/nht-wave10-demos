//Arrow function


const Demo = () =>
{
    var x=20;
    var y=9;
    
    var result = x+y;
    console.log(result);

    var result = x-y;
    console.log(result);

    var result = x/y;
    console.log(result);

    var result = x*y;
    console.log(result);

}

const fun1 =()=>
{
    console.log("This is an Arrow function");
}


Demo();
fun1();