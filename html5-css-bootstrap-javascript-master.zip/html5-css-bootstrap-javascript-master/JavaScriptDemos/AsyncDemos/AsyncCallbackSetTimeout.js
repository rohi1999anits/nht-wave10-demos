const p=100,q=200;

function sum(a,b,cd)
{
    console.log("this is the function of sum()... after this the callback will be triggered!")
    setTimeout(function()
    {
        cd(a+b);
    },5000)
;}

function division(a,b,cd)
{
    console.log("this is the function of division()... after this the callback will be triggered!")
    setTimeout(function()
    {
        cd(a/b);
    },5000)
}

sum(p,q, function(sumResult)
{
    division(sumResult, 0,function(avg)
    {
        console.log(avg);
        console.log("Async process achieved!");
    })
})