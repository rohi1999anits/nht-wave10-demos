function sum(a,b)
{
    return new Promise((resolve, reject)=>
    {
        setTimeout(function()
        {
            const sumResult = a+b;
            resolve(sumResult);
        },5000)
    })
}

function div(a,b)
{
    return new Promise((resolve, reject)=>
    {
        setTimeout(function()
        {
            const divResult = a/0;
            resolve(divResult);
        },5000)
    })
}

const promise = sum(20,4);

promise.then((sumResult)=>
{
    div(sumResult,2).then((avg)=>
    {
        console.log(avg);
    })
})
console.log("Async achieved!");