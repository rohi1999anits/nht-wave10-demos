
function fibo(val)
{
    var a=1;
    var b=0;
    
    if(!Number.isInteger(val))
    {

        console.log('NaN');
        return NaN;
    }
    else{
        console.log(b);
    console.log(a);
    while(a<val)
    {
        a= a+b;// 2+1
        b = a-b;//1-1
        console.log(a);
       
    }
}
    return a;

}

fibo("x");

module.exports = fibo;
