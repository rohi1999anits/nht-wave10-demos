class Fibonacci
{
    fibonacci(num)
    {
        if(!Number.isInteger(num))
        {
            throw new Error('The parameter must be an Integer')
        }
        if(num <0)
        {
            throw new Error('The parameter must be greater than 0');
        }
        else if (num==0)
        {
            
            return [0];
           
        }
        else if (num==1)
        {
            var x=[0,1];
            console.log(x);
            return [0,1];
            
        }
        else if (num>=2)
        {
           let arr = [0,1];
           console.log(arr);
           for(let i=2; i<num+1; i++)
           {
               arr.push(arr[i-2]+arr[i-1]);
               console.log(arr[i]);
           }
           return arr;
        }
    }
}
var fObj = new Fibonacci();
fObj.fibonacci(4);

module.exports = Fibonacci;
