CityArr =["Chicago","Delhi","Tokyo","London","Sydney"];

const arrayDemo =()=>
{
    for(i=0; i<CityArr.length;i++)
    {
        console.log(CityArr[i]);
    }

    return CityArr[i];

}

arrayDemo();

module.exports = arrayDemo;
module.exports = arrayDemo.CityArr;