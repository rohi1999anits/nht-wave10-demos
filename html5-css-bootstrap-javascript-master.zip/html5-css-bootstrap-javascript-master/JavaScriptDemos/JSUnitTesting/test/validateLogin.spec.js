const assert = require('chai').assert;

describe('Login Test Suite-1',()=>
{
    var status = true;
    var statusFail = false;

    it('Login Success',()=>
    {
        assert.equal(status,true);
    })

    it('Login Failure',()=>
    {
        assert.equal(statusFail,false);
    })
})