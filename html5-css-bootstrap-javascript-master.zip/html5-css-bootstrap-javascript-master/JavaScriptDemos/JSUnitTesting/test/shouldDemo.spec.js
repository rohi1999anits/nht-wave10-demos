var should = require('chai').should();
var actualID = 1001;

describe('Checking should',()=>
{
    it('Must verify ID type',()=>
    {
        actualID.should.not.be.a('string');
    })
    it('Must verify ID',()=>
    {
        actualID.should.equal(1001);
    })
})


