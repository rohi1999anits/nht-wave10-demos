const expect = require('chai').expect;


describe('Demo TestSuite 1',()=>
{
    before(()=>
    {
        console.log('Begining of the test cases!');
    })

    beforeEach(()=>
    {
        console.log('Begining of each test case!');
    })

    after(()=>
    {
        console.log('End of the test cases!');
    })

    afterEach(()=>
    {
        console.log('End of each test case!');
    })

    var models=['Toyota','BWM','Audi','Bentley'];

    it('Checking the type of car models',()=>
    {
        expect(models).to.be.an('Array');
    })

    
 it('Checking the number of car models',()=>
 {
     expect(models.length).to.be.equal(4);
 })

 
 it('Checking the Order of items in models',()=>
 {
     expect(models).to.have.ordered.members(['Toyota','BWM','Audi','Bentley']);
 })

 it('Must check keys of the key-value pairs',()=>
 {
     expect({a:101,b:102,c:201}).to.have.all.keys('a','c','b');
 })

})



