const add = require('../add.js');
var expect = require('chai').expect;

describe('This is the add test',()=>
{
    it('Must add two numbers',()=>
    {
        expect(add(3,4)).to.be.equal(7);
    })
})