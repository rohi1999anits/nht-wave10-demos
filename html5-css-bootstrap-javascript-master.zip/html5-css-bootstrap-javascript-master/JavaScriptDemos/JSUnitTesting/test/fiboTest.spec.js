var assert = require('chai').assert;
var expect = require('chai').expect;
var fibo = require('../fibonacci2.js');

describe('Test suite -1',()=>
{
    it('Must check fibo series',()=>
    {
        
      assert.equal(13,fibo(9));// BDD

      //expect(fibo(9)).to.be.NaN;
     

        
    })
    it('Must check fibo series',()=>
    {
        expect(fibo("val")).to.be.NaN;// TDD
    }
    )

})