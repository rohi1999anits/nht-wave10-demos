const multi= require('../multiply.js');
var expect = require('chai').expect;
var assert = require('chai').assert;


describe('This is the multiply test',()=>
{
    it('Must make a product of 2 numbers',()=>
    {
        expect (multi(4,5)).to.be.equal(20);
    })

    it('Must contain numbers',()=>
    {
        expect(23).to.be.a('Number');
    })

    it('Must contain String',()=>
    {
        assert.typeOf("Hello",'string');
    })
})