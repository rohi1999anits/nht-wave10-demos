var assert = require('chai').assert;
var isPrime = require('../primeNumber.js');

describe('Must verify prime number',()=>
{
    it('Should return  false',()=>
{
    assert.equal(false,isPrime(8));
    
})

it('Should return true ',()=>
{
    assert.equal(true,isPrime(3));
    
})
})