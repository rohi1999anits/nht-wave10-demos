let chai = require('chai');
let expect = require('chai').expect;

chai.should();

let Fibonacci = require('../fibonacci.js');

describe('Fibonacci valid returns',()=>
{
    let fib;
    beforeEach(()=>
    {
        fib = new Fibonacci();
    });

    it('should return 0',()=>
    {
        expect(fib.fibonacci(0)).to.eql([0]);
    })

    it('should return 0,1',()=>
    {
        expect(fib.fibonacci(1)).to.eql([0,1]);
    })

    it('should return 0,1,1',()=>
    {
        expect(fib.fibonacci(2)).to.eql([0,1,1]);
    })

    it('should return 0,1,1,2',()=>
    {
        expect(fib.fibonacci(3)).to.eql([0,1,1,2]);
    })

    it('should return 0,1,1,2,3',()=>
    {
        expect(fib.fibonacci(4)).to.eql([0,1,1,2,3]);
    })
    it('should return 0,1,1,2,3,5',()=>
    {
        expect(fib.fibonacci(5)).to.eql([0,1,1,2,3,5]);
    })
});

describe('Fibonacci invalid returns',()=>
{

    let fib;
    beforeEach(()=>
    {
        fib = new Fibonacci();
    });

    it('should not return 0',()=>
    {
        expect(fib.fibonacci(0)).to.not.eql([]);
    })

    it('should not return 0',()=>
    {
        expect(fib.fibonacci(0)).to.not.eql([-1]);
    })

    it('should not return 0',()=>
    {
        expect(fib.fibonacci(0)).to.not.eql([1]);
    })
})

describe('Fibonacci data type of parameters',()=>
{
   
    let fib;
    beforeEach(()=>
    {
        fib = new Fibonacci();// it was creating the actual object
    });


    it('should throw exception: The parameter must be a number',()=>
    {
        expect(()=> fib.fibonacci('a')).to.throw('The parameter must be an Integer');
   })

   it('should throw exception: The parameter must be greater than 0 and positive number',()=>
   {
       expect(()=> fib.fibonacci(-1)).to.throw('The parameter must be greater than 0');
  })


  it('should not throw exception: The parameter must be  positive number',()=>
  {
      expect(()=> fib.fibonacci()).to.not.throw('The parameter must be greater than 0');
 })
})