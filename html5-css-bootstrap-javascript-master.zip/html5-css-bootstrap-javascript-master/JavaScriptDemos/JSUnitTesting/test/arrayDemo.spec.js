const arr = require('../arrayDemo.js');
var expect = require('chai').expect;


describe('This will test an object for array format',()=>
{
    it('Must have array structure',()=>
    {
        expect(CityArr).to.be.an('Array');
    })
})