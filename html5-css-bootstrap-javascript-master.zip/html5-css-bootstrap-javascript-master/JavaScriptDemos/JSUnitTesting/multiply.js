function multiplyNum(x,y)
{
    return x*y;
}

module.exports = multiplyNum;