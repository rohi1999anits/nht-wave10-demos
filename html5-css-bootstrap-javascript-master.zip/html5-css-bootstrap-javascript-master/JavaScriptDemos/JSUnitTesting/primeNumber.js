function isPrime(val)
{
    for(var i=2;i<val;i++)
    {
        if(val%i ===0)
        {
            
            console.log("Not Prime");
            return false;
        }
        
    }
    console.log("Prime");
    return val >1;

}

isPrime(2);

module.exports= isPrime;