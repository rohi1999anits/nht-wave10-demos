const chai = require('chai');
const expect = chai.expect;
const assert = chai.assert;
const should = chai.should;
const convert2obj = require('../solution/q4_data_modelling_and_retrieval.js');



describe('Testing - data_modelling_and_retrieval',()=>
{
	const fruitArray = [
		{ name: "Banana", color: 'Yellow',pricePerKg:40 },
		{ name: "Guava", color: 'Green',pricePerKg:50 },
		{ name: "Apple", color: 'Red',pricePerKg:90 },
		{ name: "Orange", color: 'Orange',pricePerKg:70 },
		{ name: "Grapes", color: 'Purple',pricePerKg:100 }
		
	  ];

	it('Has to be array structure',()=>
    {
        expect(fruitArray).to.be.an('Array');
	});
	
	it('Checking the number of fruits', () =>
	{
        expect(fruitArray.length).to.equal(5);
    });

	it('Checking the names of fruits', () =>
	{
        expect(fruitArray[0].name).to.equal("Banana");
        expect(fruitArray[1].name).to.equal("Guava");
		expect(fruitArray[2].name).to.equal("Apple");
		expect(fruitArray[3].name).to.equal("Orange");
		expect(fruitArray[4].name).to.equal("Grapes");
        
	});

	it('object should have all the properties', () =>
	{
		for(i=0;i<fruitArray.length;i++){
		expect(fruitArray[i]).to.have.property('name');
		expect(fruitArray[i]).to.have.property('color');
		expect(fruitArray[i]).to.have.property('pricePerKg');}
		
	});
	
	it('checking not to be empty', () =>
	{
		expect(fruitArray).to.not.be.empty;
		
    });

});
