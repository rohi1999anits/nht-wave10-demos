const chai = require('chai');
const expect = chai.expect;
const convert2obj = require('../solution/q5_students_result_card.js');


describe('Testing - students_result_card',()=>
{
    const studentsList = [
        {name: 'Student1', subjects: [{subject: 'Grammar', marks: 65}, {subject: 'Accounts', marks: 59}]},
        {name: 'Student2', subjects: [{subject: 'Grammar', marks: 45}, {subject: 'Accounts', marks: 48}]},
        {name: 'Student3', subjects: [{subject: 'Grammar', marks: 80}, {subject: 'Accounts', marks: 18}]},
        {name: 'Student4', subjects: [{subject: 'Grammar', marks: 70}, {subject: 'Accounts', marks: 50}]},
        {name: 'Student5', subjects: [{subject: 'Grammar', marks: 100}, {subject: 'Physics', marks: 80}]},
        {name: 'Student6', subjects: [{subject: 'Grammar', marks: 25}, {subject: 'Physics', marks: 60}]},
        {name: 'Student7', subjects: [{subject: 'Grammar', marks: 35}, {subject: 'Physics', marks: 95}]},
        {name: 'Student8', subjects: [{subject: 'Grammar', marks: 44}, {subject: 'Physics', marks: 98}]}
      ]

      
      it('Has to be array structure',()=>
      {
        expect(studentsList).to.be.an('Array');

	    });

       it('Checking the number of students', () =>
	    {
        expect(studentsList.length).to.equal(8);

      });

      it('number of subjects for each student must be 2', () =>
	    {
        for(i=0;i<studentsList.length;i++)
        expect(studentsList[i].subjects.length).to.equal(2);

      });

      it('Checking the names of students', () =>
	    {
      expect(studentsList[0].name).to.equal('Student1');
      expect(studentsList[1].name).to.equal('Student2');
		  expect(studentsList[2].name).to.equal('Student3');
		  expect(studentsList[3].name).to.equal('Student4');
      expect(studentsList[4].name).to.equal('Student5');
      expect(studentsList[5].name).to.equal('Student6');
		  expect(studentsList[6].name).to.equal('Student7');
		  expect(studentsList[7].name).to.equal('Student8');
        
	    });

       it('object should have all the properties', () =>
	    {
      for(i=0;i<studentsList.length;i++){
		  expect(studentsList[i]).to.have.property('name');
		  expect(studentsList[i]).to.have.property('subjects');}
		  
		  });
       
       it('checking not to be empty', () =>
	    {
		  expect(studentsList).to.not.be.empty;
		
      });
 });
