package com.JunitDemo;

public class CalculationDemo 
{
////hello my name is onkar and i am having network issues	
	public static int findMax(int arr1[])
	{
		int max =0;
		for(int i=1; i<arr1.length; i++)
		{
			if(max< arr1[i])
			{
				max= arr1[i];
			}
		}
		
		System.out.println(max);
		return max;
	}
	
	
	public static String greetings(String msg)
	{
		System.out.println(msg);
		return msg;
	}

	public static void main(String[] args) 
	{
		int arr2 [] = new int[] {11,22,33,44};
		
	//	CalculationDemo.findMax(arr2);
		
		//CalculationDemo.greetings("Welcome to the world of Junit!");
		

	}

}
