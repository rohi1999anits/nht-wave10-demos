package com.JunitDemo.test;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.JunitDemo.CalculationDemo;

public class CalculationDemoTest 
{
	//Junit framework == Junit assertion library + Junit Runner
     
	@BeforeClass// this annotation will enable junit runner to invoke this method before any test case invocation
	public static void beforeAllTests() 
	{
		System.out.println("Before all the test cases.");
		
	}
		   
		@AfterClass// this annotation will enable junit runner to invoke this method after all the test cases are invoked
		public static void afterAllTests() 
		{
			System.out.println("After all the test cases.");
			
		}
		
		@Before
		public  void beforeEachTests() 
		{
			System.out.println("Before each test cases.");
			
		}
		
		   
			@After
			public  void afterEachTests() 
			{
				System.out.println("After each test cases.");
				
			}
		
		@Test// this annotation will tell junit runner that this method is test case
		public void findMaxTest()
		{
			int arr[]= new int[] {34,12,97,55};
			
			assertEquals(97, CalculationDemo.findMax(arr));
			
			
			
		}
		
		@Test
		public void greetingsTest()
		{
			Assert.assertTrue(CalculationDemo.greetings("Welcome to the world of Junit!"), true);
			
			
					
		}
		
		
		/*
		 * @Test public void greetingsAssert() {
		 * 
		 * Assert.assertNotEquals("Welcome to the world",
		 * CalculationDemo.greetings("Welcome to the world")); }
		 */
	
		
}











