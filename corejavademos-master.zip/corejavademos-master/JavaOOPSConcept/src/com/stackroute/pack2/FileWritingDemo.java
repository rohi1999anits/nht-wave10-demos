package com.stackroute.pack2;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileWritingDemo {

	public static void main(String[] args) throws IOException
	{
		
		FileOutputStream fos = new FileOutputStream("E:\\IBM\\NHT\\test.txt");
		
		String val= " India has various seasons";
		
		byte[] arr = val.getBytes();
		fos.write(arr);
		

	}

}
