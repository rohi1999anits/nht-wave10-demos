package com.stackroute.pack2;

import com.stackroute.oops.AccessSpecDemo;

public class childDemo extends AccessSpecDemo
	
{

	public static void main(String[] args) 
	{

		childDemo cd = new childDemo();
		cd.myNum();
		


	}

}
