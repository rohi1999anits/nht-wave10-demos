package com.stackroute.pack2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileReadDemo {

	public static void main(String[] args) throws Exception 
	{
		FileInputStream fis = new FileInputStream("E:\\IBM\\NHT\\test.txt");
		
		int i=0;
		
		while((i=fis.read())!=-1)// -1 is End of file (EOF)
		{
			System.out.print((char)i);
		}
		fis.close();
		
		

	}

}
