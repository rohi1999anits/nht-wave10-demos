package com.stackroute.pack2;


//extends Thread

public class ThreadDemo   implements Runnable 
{
	@Override
	public void run()
	{

		for (int i=1; i<=5; i++)
		{
			Thread t = Thread.currentThread();
			
			try {
				Thread.sleep(3000);
				System.out.println(t.getName()+"::"+i);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
	}

	public static void main(String[] args)
	{
		ThreadDemo obj1 = new ThreadDemo();// obj1 is of ThreadDemo class type
		ThreadDemo obj2 = new ThreadDemo();
		
		Thread t1 = new Thread(obj1);// obj1 is of Thread type executing ThreadDemo element
		
		Thread t2 = new Thread(obj2);
		
		t1.setName("Child Thread 1: ");
		t2.setName("Child Thread 2: ");
		
		System.out.println("Thread status "+t1.isAlive());
		
		t1.start();
		t1.setPriority(9);
		t2.start();
		
		System.out.println("Thread status "+t1.isAlive());
		
	}

	

}
