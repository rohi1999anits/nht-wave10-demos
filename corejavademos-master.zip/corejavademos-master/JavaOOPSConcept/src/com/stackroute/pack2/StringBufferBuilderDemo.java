package com.stackroute.pack2;

public class StringBufferBuilderDemo
{
	public static void StringBufferDemo()
	{
		
		StringBuffer sb = new StringBuffer("IBM");
		sb.append("-India");
		System.out.println(sb);
	}
	
	
	public static void StringBuilderDemo()
	{
		StringBuilder sb = new StringBuilder("Stackrout");
		sb.append("-India");
		System.out.println(sb);
	}

	public static void main(String[] args)
	{
	
		StringBufferBuilderDemo.StringBufferDemo();// sync..thread safe but less efficient
		
		StringBufferBuilderDemo.StringBuilderDemo();//async.. not thread safe but efficient 

	}

}
