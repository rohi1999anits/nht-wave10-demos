package com.stackroute.pack2;

public class StringFunctionDemo {

	public static void main(String[] args) 
	{
		
		String s1= "stackroute";
		
		System.out.println(s1.substring(1));
		
		System.out.println(s1.substring(0,1));
		
		String s2 = "Indian Institute of Science";
		
		s2.concat(" is the best institute.");
		
		System.out.println(s2);
		
		s2 = s2.concat(" is the best institute.");
		
		System.out.println(s2);
		
		String str3 = "A long long long time ago , in a galaxy ,  far far away.";
		
		String [] parts = str3.split(" , ");
		
		for(String x : parts)
		{
			System.out.println(x);
		}
		
		String str4 = "It is elementary my dear Watson!";
		
		String newStr4 = str4.replace("Watson", "Dr.Watson");
		
		System.out.println(newStr4);
	
		
		String upperStr = newStr4.toUpperCase();
		System.out.println(upperStr);
		
		

	}

}
