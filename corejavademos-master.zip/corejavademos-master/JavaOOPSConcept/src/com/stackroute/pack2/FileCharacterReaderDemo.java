package com.stackroute.pack2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class FileCharacterReaderDemo {

	public static void main(String[] args) throws Exception 
	{
		
		/*FileInputStream fis = new FileInputStream("E:\\IBM\\NHT\\data_ipl.csv");
		
		int i=0;
		
		while((i=fis.read())!=-1)// -1 is End of file (EOF)
		{
			System.out.print((char)i);
		}
		fis.close();*/
		
		String header;
		
		BufferedReader reader = new BufferedReader(new FileReader("E:\\IBM\\NHT\\data_ipl.csv"));
		
		header = reader.readLine();
		
		String []columns = header.split(",");
		
		for(String temp : columns)
		{
			System.out.println(temp);
		}
		
	}

}








