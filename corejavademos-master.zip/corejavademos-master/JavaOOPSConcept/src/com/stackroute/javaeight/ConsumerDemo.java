package com.stackroute.javaeight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerDemo
{
	static<T> void forEach(List<T> li, Consumer<T> consumer)
	{
		
		for(T t: li)
		{
			consumer.accept(t);
		}
	}

	public static void main(String[] args) 
	{
		
		/*List <String> abc = new ArrayList<String>();
		abc.add("ergg");
		abc.add("wewro");
		
		abc.forEach(temp->{
			System.out.println(temp);
		});*/
		
	
		List<Integer> li = Arrays.asList(11,22,33,44,55);
		
		Consumer<Integer> consumer = (Integer x)-> System.out.println(x);
		forEach(li,consumer);
		

	}

}
