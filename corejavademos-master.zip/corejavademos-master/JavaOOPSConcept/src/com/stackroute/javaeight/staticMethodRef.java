package com.stackroute.javaeight;

interface MyCar
{
	public void carSeatColor();
}

class Car
{
	public void carEngine(int cc)
	{
		int engCC = cc;
		System.out.println(engCC);
	}
	
	static String color="Black";
	public static void carSeat()
	{
		System.out.println(color);
	}
}

public class staticMethodRef {

	public static void main(String[] args) 
	{
		Car obj = new Car();
		obj.carEngine(1000);
		
		MyCar objStatic = Car :: carSeat;
		
		objStatic.carSeatColor();// this is a reference to the functional interface method carSeatColor
		
		
	}

}
