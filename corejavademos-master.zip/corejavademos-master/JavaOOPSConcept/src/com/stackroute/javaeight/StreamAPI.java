package com.stackroute.javaeight;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class StreamAPI {

	public static void main(String[] args) 
	{
		//Stream is a sequence of objects that supports various methods which can be pipeline
		//to produce the desired result.
		
	//Stream is not a data structure. But it is used to work on DS.
		
		List<Product > objList = new ArrayList<Product>();
		
		objList.add(new Product(200,"Dairy"));
		objList.add(new Product(300,"Cereal"));
		objList.add(new Product(500,"Pulses"));
		objList.add(new Product(800,"Organic"));
		
		Collections.sort(objList,(Product p1, Product p2)-> p1.getPname().compareTo(p2.getPname()));
		
		objList.forEach(temp->{
			System.out.println(temp.getPname());
			
		}
		
		);
		
		//List <String> abc = objList.stream().filter(predicate);
		List<String> strObj = objList.stream().filter(n-> n.pname =="Pulses").map(n->n.pname).collect(Collectors.toList());
		System.out.println(strObj);

	}

}
