package com.stackroute.javaeight;

import java.util.function.IntPredicate;

public class PredicateDemo {

	public static void main(String[] args) 
	{
		IntPredicate lesser = age -> age <18;
		
		IntPredicate greater = age -> age >10;
		
		
		System.out.println(lesser.and(greater).test(19));
		
		
		
		int x =19;
		
		if(x >10 && x < 18)
		{
			System.out.println("Valid!");
		}
		
		/*
		 * int x =19;
		 * 
		 * if(x >10 & x < 18) { System.out.println("Valid!"); }
		 */
		

	}

}
