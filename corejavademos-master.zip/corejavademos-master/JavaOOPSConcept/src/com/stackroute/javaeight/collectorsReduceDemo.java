package com.stackroute.javaeight;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class collectorsReduceDemo {

	public static void main(String[] args) 
	{
		
		List<Product> objList = new ArrayList<Product>();
		
		objList.add(new Product(100,"a"));
		objList.add(new Product(200,"b"));
		objList.add(new Product(190,"c"));
		objList.add(new Product(160,"d"));
		objList.add(new Product(340,"e"));
		objList.add(new Product(721,"f"));
		
		objList.forEach(temp ->{
			System.out.println(temp.getPrice());
		});
		
		
	//	double sumOfPrice = objList.stream().collect(Collectors.);
		double sumOfPrice = objList.stream().collect(Collectors.summingDouble(p -> p.getPrice()));
		
		System.out.println(sumOfPrice);
		
		Product prod = objList.stream().collect(Collectors.maxBy(Comparator.comparingInt(Product::getPrice))).get();
		System.out.println(prod);
		
		
	}

}
