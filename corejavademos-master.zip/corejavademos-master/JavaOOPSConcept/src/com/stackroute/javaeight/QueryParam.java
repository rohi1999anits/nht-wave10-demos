package com.stackroute.javaeight;

public class QueryParam
{
	private String selectPart;
	
	private String fieldParts;
	
	private String fromPart;
	
	private String fileName;

	public String getSelectPart() {
		return selectPart;
	}

	public void setSelectPart(String selectPart) {
		this.selectPart = selectPart;
	}

	public String getFieldParts() {
		return fieldParts;
	}

	public void setFieldParts(String fieldParts) {
		this.fieldParts = fieldParts;
	}

	public String getFromPart() {
		return fromPart;
	}

	public void setFromPart(String fromPart) {
		this.fromPart = fromPart;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public QueryParam(String selectPart, String fieldParts, String fromPart, String fileName) {
		super();
		this.selectPart = selectPart;
		this.fieldParts = fieldParts;
		this.fromPart = fromPart;
		this.fileName = fileName;
	}

	public QueryParam() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "QueryParam [selectPart=" + selectPart + ", fieldParts=" + fieldParts + ", fromPart=" + fromPart
				+ ", fileName=" + fileName + "]";
	}

	
}













