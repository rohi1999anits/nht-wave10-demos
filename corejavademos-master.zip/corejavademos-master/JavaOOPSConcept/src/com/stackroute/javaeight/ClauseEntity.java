package com.stackroute.javaeight;

public class ClauseEntity {

}
