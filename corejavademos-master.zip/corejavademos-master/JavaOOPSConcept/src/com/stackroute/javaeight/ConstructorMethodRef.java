package com.stackroute.javaeight;

@FunctionalInterface
interface StudentFactory
{
	public Student getStudent(Integer sid, String sname);
}


class Student implements Runnable
{
	Integer sid;
	String sname;
	public Student(Integer sid, String sname) {
		super();
		this.sid = sid;
		this.sname = sname;
		System.out.println(sid+"-->"+sname);
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
}

public class ConstructorMethodRef 
{

	public static void main(String[] args)
	{
		StudentFactory sObj = Student :: new;
		Student stuObj = sObj.getStudent(101, "Noah");
		System.out.println(stuObj);
		

	}

}
