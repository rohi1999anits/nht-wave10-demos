package com.stackroute.javaeight;

public class Product 
{
	 int price;
	 String pname;
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	

	
	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Product(int price, String pname) {
		super();
		this.price = price;
		this.pname = pname;
	}

	@Override
	public String toString() {
		return "Product [price=" + price + ", pname=" + pname + "]";
	}
	
	

}
