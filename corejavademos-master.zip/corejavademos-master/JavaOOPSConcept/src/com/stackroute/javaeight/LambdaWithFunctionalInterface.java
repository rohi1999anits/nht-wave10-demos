package com.stackroute.javaeight;


//functional Interface

@FunctionalInterface
interface Logo
{
	public void logoImage();
	
}

class SalonCar 
{
	//Logo obj = new SalonCar();
	
	public static Object call()
	{
		Logo obj = ()->
		{
			System.out.println("This is another method implementing logoImage() from Logo Funcitonal Interface!");
			
		};
		
		obj.logoImage();
		return obj;
	}
}

public class LambdaWithFunctionalInterface {

	public static void main(String[] args)
	{
		SalonCar.call();// till java 1.7
		
		String  imageName = "VolswagenLogo";
		
		Logo objlogo= ()->
		{
			System.out.println(imageName);
		};
		
		objlogo.logoImage();
		
		Logo logoObj2 = SalonCar :: call;// since java 1.8
		logoObj2.logoImage();

	}

}
