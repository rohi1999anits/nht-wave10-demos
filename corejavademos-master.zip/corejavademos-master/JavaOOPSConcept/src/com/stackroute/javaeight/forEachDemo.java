package com.stackroute.javaeight;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class forEachDemo {

	public static void main(String[] args) 
	{
	
		//forEach is a loop
		//List<Integer> abc = new ArrayList<Integer>();
		
		//abc.add(11);
		//abc.add(22);
		//abc.add(33);
		
		List<QueryParam> objList= new ArrayList<QueryParam>();
		QueryParam o1 = new QueryParam("select","date","from","ipl.csv"); 
		objList.add(o1);
		objList.add(new QueryParam("select","city","from","ipl.csv"));
		objList.add(new QueryParam("select","winner","from","ipl.csv"));
		objList.add(new QueryParam("select","season","from","ipl.csv"));
		
		objList.forEach(temp2 ->{
			System.out.println(temp2.getFieldParts());
		});
		
		Collections.sort(objList,(QueryParam qp1, QueryParam qp2)-> qp1.getFieldParts().compareTo(qp2.getFieldParts()));
		
		
		objList.forEach(temp ->{
			System.out.println(temp.getFieldParts());
		});
		
		
		
	}

}
