package com.stackroute.javaeight;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.function.Supplier;

public class SupplierDemo {

	private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
	
	public static void main(String[] args) 
	{
		//Supplier is a @FuntionalInterface in Java 1.8
		//It is used to take out any operation in java and return a value.
		
		Supplier<LocalDateTime>  sup= () -> LocalDateTime.now();
		
		LocalDateTime time = sup.get();
		
		System.out.println(time);
		
		Supplier<String> str = () ->dtf.format(LocalDateTime.now());
		String time2 = str.get();
		
		System.out.println(time2);
		
	}

}
