package com.stackroute.coll;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDequeDemo {

	public static void main(String[] args)
	{
		Deque<String > obj =new ArrayDeque<String>();
		
		obj.add("India");
		obj.add("China");
		obj.add("USA");
		
		for(String s: obj)
		{
			System.out.println(s);
		}
		
		obj.pollFirst();
		
		obj.pollLast();
		for(String s: obj)
		{
			System.out.println(s);
		}

	}

}
