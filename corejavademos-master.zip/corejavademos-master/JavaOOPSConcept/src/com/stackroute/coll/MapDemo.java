package com.stackroute.coll;

import java.util.HashMap;
import java.util.Map;

public class MapDemo 
{
	public static void fruits()
	{
		String [] arr = new String[3];
		arr[0]="Mango";
		arr[1]="apple";
		arr[2]="Grapes";
		
		/*
		 * for(int i=0;i<arr.length;i++) {
		 * 
		 * }
		 */
		for(String x :arr)
		{
			System.out.println(x);
		}
		
	}
	
	public static void main(String []abc)
	{
		MapDemo.fruits();
		Map <Integer, String> mapObj = new HashMap<Integer,String>();
		
		mapObj.put(101,"Seth");
		mapObj.put(102,"Meredith");
		mapObj.put(103,"Jerome");
		
		for(Map.Entry m:mapObj.entrySet())
		{
			System.out.println(m.getKey()+"-->"+m.getValue());
		}
		
		
	}
	
	

}
