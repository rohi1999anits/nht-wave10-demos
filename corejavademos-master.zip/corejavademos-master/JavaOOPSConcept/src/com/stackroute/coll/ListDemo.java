package com.stackroute.coll;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListDemo {

	public static void main(String[] args)
	{
		
		List<String> obj = new ArrayList<String>();
		
		obj.add("World Peace!");
		obj.add("Afforestation!");
		obj.add("Afforestation!");
		obj.add("Afforestation!");
		
		Iterator<String> itr = obj.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		



	}

}
