package com.stackroute.coll;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args)
	{
		Set<String> obj = new TreeSet<String>();
		
		obj.add("India");
		obj.add("USA");
		obj.add("Germany");
		obj.add("India");
		
		Iterator<String> itr = obj.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		

	}

}
