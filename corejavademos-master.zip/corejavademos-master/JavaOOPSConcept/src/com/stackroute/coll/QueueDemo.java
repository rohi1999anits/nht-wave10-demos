package com.stackroute.coll;

import java.util.Iterator;
import java.util.PriorityQueue;

public class QueueDemo {

	public static void main(String[] args) {
		
		PriorityQueue<String> obj = new PriorityQueue<String>();
		
		obj.add("Chicago");
		obj.add("New York");
		obj.add("Dallas");
		obj.add("Seattle");
		obj.add("CA");
		
		System.out.println("Queue head "+ obj.element());
		
		System.out.println("Queue Head "+ obj.peek());// this return null
		
		Iterator<String> itr = obj.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		obj.remove();
System.out.println("Queue head "+ obj.element());
		
		System.out.println("Queue Head "+ obj.peek());// this return null
		obj.poll();
		obj.poll();
		obj.poll();
		obj.poll();
		
		//System.out.println("Queue head "+ obj.element());
		System.out.println("Queue Head "+ obj.peek());// this return null
		
		Iterator<String> itr2 = obj.iterator();
		
		while(itr2.hasNext())
		{
			System.out.println(itr2.next());
		}

	}

}
