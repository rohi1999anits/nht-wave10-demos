package com.stackroute.oops;


class MyOwnException extends Exception
{
	public MyOwnException(String msg)
	{
		super(msg);
	}
}

public class UserExceptionDemo
{                                   // declare the exception in the calling environment
	static void employeeAge(int age) throws MyOwnException
	{
		if(age<=0)
		{
		// throw->to intimate the user
			throw new MyOwnException("Age invalid... cannot be <= 0");
		}
		else
		{
			System.out.println("Age is valid");
		}
	}

	public static void main(String[] args) 
	{
		
		try {
			employeeAge(-2);
		} catch (MyOwnException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
