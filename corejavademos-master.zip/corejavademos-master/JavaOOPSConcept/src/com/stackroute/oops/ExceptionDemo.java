package com.stackroute.oops;

public class ExceptionDemo {

	public static void main(String[] args) 
	{
		try
		{
			int x= 50/0;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("Code has been released from memory!");
		}
		

	}

}
