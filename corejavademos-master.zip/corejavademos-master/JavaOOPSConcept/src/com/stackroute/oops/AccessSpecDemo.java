package com.stackroute.oops;

// class is logical unit that holds reference to all it's properties
//object is a representative of the class


public class AccessSpecDemo 
{

	protected void myNum()
	{
		System.out.println("My number is: 378937938");
	}
	

	public static void main(String[] args) 
	{
     //class name /object   //new   /default constructor
		AccessSpecDemo    obj   =    new    AccessSpecDemo();
		AccessSpecDemo    obj1   =    new   AccessSpecDemo();
		obj.myNum();
		
		obj1.myNum();
	}

}
