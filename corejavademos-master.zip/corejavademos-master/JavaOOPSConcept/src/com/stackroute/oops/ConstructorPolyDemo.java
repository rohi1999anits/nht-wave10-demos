package com.stackroute.oops;


class compute
{
	
	public  compute(int num1, int num2)
	{
		System.out.println(num1+num2);
	}
	
	
	public  compute(int num1, int num2, String msg)
	{
		System.out.println(num1*num2+" The Message is: "+ msg);
	}
		
	public  compute(String name)
	{
		System.out.println("The name is" + name);
	}
}
public class ConstructorPolyDemo {

	public static void main(String[] args)
	{
		compute c = new compute(2,3);
		
		compute c2 = new compute(4,5, "World Peace");
		
		compute c3 = new compute("Hello All!");
		
		

	}

}
