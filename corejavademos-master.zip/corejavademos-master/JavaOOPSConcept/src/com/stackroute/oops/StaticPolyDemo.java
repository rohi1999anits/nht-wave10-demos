package com.stackroute.oops;


class Calc
{
	
	public void compute(int num1, int num2)
	{
		System.out.println(num1+num2);
	}
	
	/*
	 * public int compute(int num1, int num2) {
	 * 
	 * return num1+num2; //System.out.println
	 * 
	 * }
	 */
	
	public void compute(int num1, int num2, String msg)
	{
		System.out.println(num1*num2+" The Message is: "+ msg);
	}
		
	public void compute(String name)
	{
		System.out.println("The name is" + name);
	}
}

public class StaticPolyDemo {

	public static void main(String[] args) 
	{
		Calc obj = new Calc();
		
		obj.compute("John");
		
		obj.compute(23,2);
		
		obj.compute(2,3,"World Peace");
		
		//System.out.println

	}

}
