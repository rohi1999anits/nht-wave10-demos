package com.stackroute.oops;

public class Car 
{
	public void engCC(int cc)
	{
		System.out.println(cc);
		
	}

}
