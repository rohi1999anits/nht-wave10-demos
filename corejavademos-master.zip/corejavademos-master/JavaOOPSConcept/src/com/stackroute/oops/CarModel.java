package com.stackroute.oops;

public abstract class CarModel 
{
	public abstract void smallCar();
	public abstract void hatchBack();

}
