package com.stackroute.oops;

public interface CarSeat 
{
	public void seatType();
	
	public void seatColor();
	
	public void seatMaterial();

}
