package com.stackroute.oops;

public class smallCarDemo extends CarModel implements CarSeat
{
	

	public static void main(String[] args)
	{
		
      // CarModel obj = new CarModel(); not allowed
		
		CarModel obj = new smallCarDemo(); //upcasting
       
       obj.smallCar();
       obj.hatchBack();
       
       CarSeat obj2 = new smallCarDemo();
       obj2.seatColor();
       obj2.seatType();
       obj2.seatMaterial();
       
       smallCarDemo obj3 = new smallCarDemo();
       obj3.price();
       
	}
    public void price()
    {
    	System.out.println("The price is 5 lacs");
    }
	
	@Override
	public void smallCar() 
	{
		System.out.println("This is the overriden smallCar()");
		
		
	}

	@Override
	public void hatchBack() {
		System.out.println("This is the overriden hatchBack()");
		
	}

	@Override
	public void seatType() 
	{
		System.out.println("The seat type is classic recliner");
		
		
	}

	@Override
	public void seatColor() {
		System.out.println("The seat color is biege");
		
	}

	@Override
	public void seatMaterial() {
		System.out.println("The seat material is leather and coir");
		
	}

}
