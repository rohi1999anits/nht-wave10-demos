package com.stackroute.oops;


//all java classes inherit from Object

public class demo1 //extends Object
{
	
	
	public static void main(String[] args) 
	{
		
     System.out.println("Hello World!");
	}

}
