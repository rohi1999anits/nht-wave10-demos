
package com.stackroute.oops;


public class Sedan extends Car
{
	@Override
	public void engCC(int num)
	{
		System.out.println("The engine capacity is: "+num);
	}

	public static void main(String[] args) 
	{
		Sedan obj = new Sedan();
		obj.engCC(999);
		
		Car c = new Car();
		c.engCC(1000);
		
	}

}
