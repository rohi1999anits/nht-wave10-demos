package com.stackroute.DaoPack;

import java.util.List;

public interface StudentDao
{
	public List<Student> getAllStudents();
	

}
