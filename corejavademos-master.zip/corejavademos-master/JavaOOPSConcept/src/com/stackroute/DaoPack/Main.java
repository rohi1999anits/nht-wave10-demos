package com.stackroute.DaoPack;

public class Main 
{
	
	public static void main(String []abc)
	{
		StudentDao daoObj = new StudentDaoImpl();
		
		for(Student s: daoObj.getAllStudents())
		{
			System.out.println(s.getSid()+"-->"+s.getSname());
		}
	}

}
