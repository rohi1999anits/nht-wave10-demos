package com.stackroute.DaoPack;

import java.util.ArrayList;
import java.util.List;

public class StudentDaoImpl implements StudentDao
{
	List<Student> stuList;
	
	//List<Integer> x = new ArrayList<Integer>();
	//x.add(1);
	
	public StudentDaoImpl()
	{
		stuList = new ArrayList<Student>();
		
		Student stuObj = new Student(101,"Robert");
		Student stuObj1 = new Student(102,"Penelope");
		stuList.add(stuObj);
		stuList.add(stuObj1);
		
	}
	

	
	@Override
	public List<Student> getAllStudents() // retrieve from DB
	{
		
		
		return stuList;
	}

}
