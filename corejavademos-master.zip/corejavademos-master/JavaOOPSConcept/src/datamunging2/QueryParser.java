/*
 * package datamunging2;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * public class QueryParser {
 * 
 * public QueryParameter parseQuery(String queryString) { String baseQuery
 * ="select * from ip.csv";
 * 
 * 
 * QueryParamter qp = new QueryParamter();
 * 
 * qp.setFields(getField(baseQuery)); //parse the query string //construct the
 * qp.setRestrictions(getRestrctions()); QueryParameter
 * 
 * //return Query Parameter object }
 * 
 * 
 * private List<String> getField(String baseQuery) { //String [] fields =
 * baseQuery.trim().split(("select")[1].split("from")[0].trim().split(", ");
 * List<String> fieldList = new ArrayList<>();
 * 
 * for(String field: fields) {
 * 
 * fieldList.add(field.trim()); } return fieldList; }
 * 
 * 
 * private List<Restriction> getRestrcition() {
 * 
 * String [] temp = whereClauseQuery.split("\\s+and\\s+or\\s+");
 * 
 * String propName; // name of the restriction
 * 
 * String propVal; // value of the clause
 * 
 * String condition; // filter condition
 * 
 * String propNameAndValue[]; // values like <, <=, >, >=, !=
 * 
 * restriction = new ArrayList<Restriction>();
 * 
 * if(whereClauseQuery !=null) { for(String expression : temp) { expression =
 * expression.trim();
 * 
 * propNameAndValue = expression.split("<|<=|>|>=|!=|=="); propName =
 * propNameAndValue[0].trim();
 * 
 * 
 * propVal = propNameAndValue[1].trim().replace("'","");
 * 
 * condition =
 * expression.split((propName)[1].split(propVal)[0].replace(".","").trim();
 * 
 * restrictions = new Restriction(propName, propVal,condition);
 * restriction.add(restriction);
 * 
 * return restriction;
 * 
 * 
 * } }
 * 
 * }
 * 
 * 
 * }
 * 
 * 
 * 
 * 
 * 
 * 
 */