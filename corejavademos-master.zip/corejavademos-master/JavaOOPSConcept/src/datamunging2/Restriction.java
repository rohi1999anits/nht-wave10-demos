package datamunging2;

public class Restriction 
{
	
	private String propName;
	
	private String propVal;
	
	private String condition;

	
	
	public String getPropName() {
		return propName;
	}



	public void setPropName(String propName) {
		this.propName = propName;
	}



	public String getPropVal() {
		return propVal;
	}



	public void setPropVal(String propVal) {
		this.propVal = propVal;
	}



	public String getCondition() {
		return condition;
	}



	public void setCondition(String condition) {
		this.condition = condition;
	}



	public Restriction(String propName, String propVal, String condition) {
		super();
		this.propName = propName;
		this.propVal = propVal;
		this.condition = condition;
	}

}
