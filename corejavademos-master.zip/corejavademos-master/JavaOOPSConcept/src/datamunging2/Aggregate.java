package datamunging2;

public class Aggregate
{
	
	private String field;

	public Aggregate(String field) {
		super();
		this.field = field;
	}
	
	private String function;

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}
	

}
