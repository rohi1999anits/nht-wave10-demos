package datamunging2;

import java.util.List;

public class QueryParamter
{
	
	
	 public QueryParamter() {
		super();
		// TODO Auto-generated constructor stub
	}
	String  queryString ;
	 String   file  ;
	  String  baseQuery;
	  List<Restriction> restrictions;
	  
		 public List<Restriction> getRestrictions() {
		return restrictions;
	}
	public void setRestrictions(List<Restriction> restrictions) {
		this.restrictions = restrictions;
	}
		List<String> fields;
		public List<String> getFields() {
			return fields;
		}
		public void setFields(List<String> fields) {
			this.fields = fields;
		}
	/*- QUERY_TYPE -> String
		  ( Array/group of restrictions.  A query may have multiple restrictions/filter conditions)
		- logicalOperators : List<String>
		- aggregateFunctions -> List<AggregateFunction>
		- orderByFields : List<String>
		- groupByFields  :  List<String>*/
	public String getQueryString() {
		return queryString;
	}
	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getBaseQuery() {
		return baseQuery;
	}
	public void setBaseQuery(String baseQuery) {
		this.baseQuery = baseQuery;
	}
	public QueryParamter(String queryString, String file, String baseQuery) {
		super();
		this.queryString = queryString;
		this.file = file;
		this.baseQuery = baseQuery;
	}


}
