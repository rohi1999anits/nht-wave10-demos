package com.JsonGsonDemo;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws Exception 
	{
		
		Scanner scanObj = new Scanner(System.in);
		
		String queryString;
			
		
		System.out.println("Please enter the query for csv database");
		
		System.out.println("=>>");
		
		queryString = scanObj.nextLine();
		
		
		//assgn 5-> the line will be added above --> Query queryObj = new Query();
		JsonWriter jsonObj = new JsonWriter();
		
		
		//assign-> jsonObj.writeToJsonFile(queryObj.executeQuery(queryString))
		if(jsonObj.writeToJsonFile(queryString))
		{
			System.out.println("Output has been written to JSON file");
		}
		
		
		

	}

}
