package com.JsonGsonDemo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JsonWriter 
{                               //assign 5-> Map resultSet
	public boolean writeToJsonFile(String resultSet) throws Exception
	{
		BufferedWriter writerObj = null;
		
		Gson gsonObj = new GsonBuilder().setPrettyPrinting().create();
		
		String result = gsonObj.toJson(resultSet);
		
		try
		{
		writerObj = new BufferedWriter(new FileWriter("data/result.json"));
		
		writerObj.write(result);
		return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		finally
		{
			try
			{
				writerObj.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
	}

}







