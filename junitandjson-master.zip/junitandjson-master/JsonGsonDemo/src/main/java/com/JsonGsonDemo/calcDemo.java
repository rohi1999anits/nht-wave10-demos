package com.JsonGsonDemo;

public class calcDemo {

	public static void main(String[] args) 
	{
		
		int a=2,b=6,c;
		
		String op ="+";
		
		switch(op)
		{
		case "+": c= a+b;
		System.out.println(c);
		
		case "-": c= a-b;
		System.out.println(c);
		
		case "/": c= a/b;
		System.out.println(c);
		
		case "*": c= a*b;
		System.out.println(c);
		}
		

	}

}
